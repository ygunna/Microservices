package com.crossent.microservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.annotation.PostConstruct;
import java.net.URI;

@Controller
@RefreshScope
public class FrontController {

	private static final Logger logger = LoggerFactory.getLogger(FrontController.class);

	@Autowired
	private RestTemplate searchClient;

//	@RequestMapping("/")
//	public String home() {
//		return "index.html";
//	}

	@RequestMapping("/test")
	@ResponseBody
	public String test() {
		System.out.println(">>>>>>>>>>>>> password is: " + password);
		return "result is "+ password;
	}

	@RequestMapping("/api/search")
	@ResponseBody
	public Data[] search(Model model) {
		System.out.println("request /api/search");

		URI uri = URI.create("http://apigateway/back/search/get");
		Data[] obj = searchClient.postForObject(uri, null, Data[].class);

		model.addAttribute("datas", obj);

		return obj;
	}

	@RequestMapping("/api/searchTwo")
	@ResponseBody
	public Data[] searchTwo(Model model) {
		System.out.println("request /api/searchTwo");

		URI uri = URI.create("http://apigateway/back/search/getTwo");
		Data[] obj = searchClient.postForObject(uri, null, Data[].class);

		model.addAttribute("datas", obj);

		return obj;
	}

	@RequestMapping("/api/searchThree")
	@ResponseBody
	public Data[] searchThree(Model model) {
		System.out.println("request /api/searchThree");

		URI uri = URI.create("http://apigateway/back/search/getThree");
		Data[] obj = searchClient.postForObject(uri, null, Data[].class);

		model.addAttribute("datas", obj);

		return obj;
	}


	@Value("${password:}")
	String password;

	@PostConstruct
	private void postConstruct() {

		System.out.println("My password is: " + password);
	}

}

@Configuration
class AppConfiguration {

	@LoadBalanced
	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
